
/*********************************************************************************************************************
 * @file       		�ܰ���ͷ�ļ�
 * @date       		2024-03-06
 * @note          
 ********************************************************************************************************************/


#ifndef __HEADFILE_H_
#define __HEADFILE_H_

//------STC32G SDK------//
#include "STC32Gxx.h"
#include "board.h"
#include "common.h"

#include "isr.h"
#include <string.h>
#include <stdio.h>
#include "intrins.h"
#include <math.h>

//------��������ͷ�ļ�------//
#include "uart.h"
#include "gpio.h"
#include "iic.h"
#include "adc.h"
#include "spi.h"
#include "tim.h"
#include "pwm.h"
#include "nvic.h"
#include "exti.h"
#include "delay.h"
#include "eeprom.h"
#include "fifo.h"
#include "WIRELESS.h"

//------��Ʒ����ͷ�ļ�------//
#include "TSL1401.h"
#include "FUNCTION.h"
#include "CONFIG.h"
#include "DL1A.h"
#include "DL1B.h"

//------�û�ͷ�ļ�-----//
#include "header.h"

#endif